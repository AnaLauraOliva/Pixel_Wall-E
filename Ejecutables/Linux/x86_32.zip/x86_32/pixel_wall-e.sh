#!/bin/sh
echo -ne '\033c\033]0;Pixel_Wall-E\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/pixel_wall-e.x86_32" "$@"
